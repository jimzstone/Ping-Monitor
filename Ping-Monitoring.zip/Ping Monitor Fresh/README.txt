PING MONITOR 1.3.0 — HOW TO USE

GET STARTED
1. Extract the ZIP to a permanent folder and exit any older app copies.
2. Open PingMonitor.exe.
3. Enter a website, full HTTP/HTTPS URL, or IP address (example: google.com).
4. Choose appearance options, then click Start / Apply.
5. Watch the first line for the latest ping and the second for extra statistics.

The app needs Windows with .NET Framework 4.x. No installer is required.
It checks ICMP reachability, not HTTP website health. Some websites block ping.

PANEL AND CONTROLS
Right-click the panel or tray icon for controls. Double-click for settings.
Turn off Lock panel beside taskbar icons to drag using the text or face.
Use Connection details for resolved IP and complete session statistics.
Pause/resume, reset statistics, hide/show the panel, export CSV, or Exit
from the menu. Changing the target or resetting clears the current results.
Taskbar placement is a floating overlay and does not reserve taskbar space.

STATUS FACES
Happy: latest reply succeeded and recent loss is below the chosen threshold.
Dizzy: a reply was missed, or recent loss reached the threshold (default 20%).
Dead: three consecutive failed probes, including timeouts or DNS errors.
Neutral: waiting for the first result, or paused.
Faces use up to the last 20 probes. Displayed statistics cover the session.

APPEARANCE
Choose dark/light mode, border color, and a panel width of 180–400 pixels.
Transparent background removes the fill but keeps the face, text and border.
Empty transparent areas pass mouse clicks through; drag using the text or face.
Opacity (35–100%) affects the entire panel. Increase it for easier reading.
The second line can show loss + average, min/average/max, received/lost,
or the last response status. Long hostnames are shortened to preserve latency.

BACKGROUND AND WINDOWS STARTUP
Fullscreen apps hide the panel by default while probes continue in background.
Windows must be awake. Unusual fullscreen or taskbar layouts may need adjustment.
To start on sign-in, check Start automatically when I sign in to Windows,
then click Start / Apply. Automatic launches use your saved website.
Manual launches open settings. Disable the checkbox and Apply to stop startup.
After moving/upgrading the executable, open the new copy and Apply again to
update the startup path. Exit old copies to avoid duplicate panels.

PING / SPEEDTEST.NET BUTTON
Click Ping / Speedtest.net in settings or the right-click menu to open:
https://www.speedtest.net/
Start the test on that website to view its latency and speed results.
This button opens your browser; it does not run a test automatically or import
results into Ping Monitor. The panel continues its own target's ICMP probes.

DONATIONS
Click Donate in settings or Donate · QR codes in the right-click menu.
Choose MariBank, GCash, or Maya using the labeled colored icons.
Scan the displayed QR in your banking/wallet app, or choose Save QR image.
Only cropped QR images with white scanning margins are included and saved.
Names, account labels, and full screenshots are removed from the donation UI
and package. There is no View original option.
The QR payment data remains unchanged; the payment app may still identify
the recipient after scanning. Donations are completed in your banking app.
Ping Monitor does not initiate a transfer or collect payment information.

CONTACT
For concerns, suggestions, or donation questions, choose Contact the owner:
https://www.facebook.com/jimzstone/
This opens Facebook without sending a message automatically.

EXPORT AND SETTINGS
CSV export retains up to 10,000 recent results: time, host, IP, latency, status.
Results stay in memory until exported; exiting clears them.
Probe delay: 500–10,000 ms after completion; timeout: 2 seconds.
Preferences: %LOCALAPPDATA%\CompactPingMonitor\settings.xml
Startup: HKCU\Software\Microsoft\Windows\CurrentVersion\Run,
value CompactPingMonitor. This package reuses existing preferences.
To reset settings, exit all copies and remove settings.xml. Disable startup
and Apply before removing the app or resetting its preferences.

TROUBLESHOOTING
No panel: check the tray icon, hide/fullscreen options, and old app copies.
Wrong location: choose Move beside taskbar icons or unlock and drag.
No response: try another known host; ICMP failure alone does not mean all
internet access or the website's HTTP service is down.
Unreadable text: increase opacity, change theme, or turn off transparency.
Old version at startup: open this copy and Apply with startup enabled.

PACKAGE
PingMonitor.exe: app with embedded QR assets and in-app instructions.
README.txt: instructions and features.
This clean release contains only the application and this README.
Version 1.3.0 includes the latest plain-font help-window fix.

